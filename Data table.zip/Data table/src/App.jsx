import './App.css'
import Api from './component/Api'

function App() {

  return (
    <>
      <Api />
    </>
  )
}

export default App
